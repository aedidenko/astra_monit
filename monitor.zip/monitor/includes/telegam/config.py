#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
Переименуйте файл в "config.py" и отредактируйте. При обновлении он не будет заменяться.
Как установить telepot и получить token бота: http://telepot.readthedocs.io/en/latest/
'''

#Список id юзеров через запятую
USER_ID = '385177024'
TOKEN = '434697961:AAGwnJLkCC_xeJQXyXhBeO-9HEHj5LscNac'
URL_TO_RRD_GRAPH = 'http://127.0.0.1/nvrn/rrdtool/graph/'
