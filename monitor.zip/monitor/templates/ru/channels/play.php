﻿	<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>
	<video id="video" width="640" height="350" src="blob:http://conture.by/2142509f-067a-44af-8dbd-7487f576330d" controls></video>
	<script>
	  if(Hls.isSupported()) {
	    var video = document.getElementById('video');
	    var hls = new Hls();
	    hls.loadSource('{http}/index.m3u8');
	    hls.attachMedia(video);
	    hls.on(Hls.Events.MANIFEST_PARSED,function() {
	      video.play();
	  });
	 }
	 // hls.js is not supported on platforms that do not have Media Source Extensions (MSE) enabled.
	 // When the browser has built-in HLS support (check using canPlayType), we can provide an HLS manifest (i.e. .m3u8 URL) directly to the video element throught the src property.
	 // This is using the built-in support of the plain video element, without using hls.js.
	  else if (video.canPlayType('application/vnd.apple.mpegurl')) {
	    video.src = '{http}/index.m3u8';
	    video.addEventListener('canplay',function() {
	      video.play();
	    });
	  }
	</script>
