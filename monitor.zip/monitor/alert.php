<?php
//if (isset($channel_name_ok['name'])) {
//    if (defined('TELEGRAM')) {alert_telegram_msg($channel_name_ok['name'], $channel_name_ok['astraname'], "работает", "\xE2\x9C\x85");}
//}
//function alert_telegram_msg($smile) {
//    exec ("includes/telegam/send_msg.py '$smile'");
//}
?>
