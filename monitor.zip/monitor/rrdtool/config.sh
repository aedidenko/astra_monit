#Переименуйте файл в "config.sh" и отредактируйте. При обновлении он не будет заменяться.

my_user="root"
my_pass="2207811"
my_db="astra"
my_host="127.0.0.1"
db_path="/var/www/html/astra_monitor/rrd/"
graph_path="/var/www/html/astra_monitor/rrdtool/graph/"
